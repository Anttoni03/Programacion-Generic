
package Taller1;

public class InsercionDatosException extends Exception{
    
    public InsercionDatosException(String missatge)
    {
        super(missatge);
    }
}
